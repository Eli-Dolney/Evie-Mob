import { world, system, Player, EntityComponentTypes, GameMode, InputButton, ButtonState } from '@minecraft/server';
import { FOOD, decodeState, feed, interaction, itemRemainder, canRide, swimVector } from './state.js';
const STATE_KEY = 'ltw_mobs:state';
const MOUNT_KEY = 'ltw_mobs:last_mount';
const VERSION = '0.1.0';
const tracked = new Map();
const takeoffs = new Map();
const swimModes = new Map();
const lastRiders = new Map();
const cooldowns = new Map();
const messages = new Map();
const lastErrors = new Map();
function kindOf(entity) {
    return entity.typeId === 'ltw_mobs:evie' ? 'evie' : entity.typeId === 'ltw_mobs:eli' ? 'eli' : undefined;
}
function stateOf(entity) {
    const state = decodeState(entity.getDynamicProperty(STATE_KEY));
    const nativeOwner = entity.getComponent(EntityComponentTypes.Tameable)?.tamedToPlayerId;
    // Native ownership is authoritative if a save was interrupted during taming.
    if (nativeOwner && state.owner !== nativeOwner) {
        state.owner = nativeOwner;
        state.trust = 5;
        state.trustingPlayer = nativeOwner;
    }
    return state;
}
function save(entity, state) {
    entity.setDynamicProperty(STATE_KEY, JSON.stringify(state));
}
function report(context, error) {
    const key = context + ':' + String(error);
    if ((lastErrors.get(key) ?? -1000) + 200 > system.currentTick)
        return;
    lastErrors.set(key, system.currentTick);
    console.warn(`[LTW Mobs ${VERSION}] ${context}: ${error}`);
}
function tell(player, text) {
    const key = player.id + ':' + text;
    if ((messages.get(key) ?? -1000) + 10 > system.currentTick)
        return;
    messages.set(key, system.currentTick);
    player.onScreenDisplay.setActionBar(text);
}
function showHearts(entity) {
    try {
        entity.dimension.spawnParticle('minecraft:heart_particle', {
            ...entity.location, y: entity.location.y + (kindOf(entity) === 'evie' ? 3.1 : 2.3)
        });
    }
    catch (error) {
        report('heart particle', error);
    }
}
function held(player) {
    return player.getComponent(EntityComponentTypes.Inventory)?.container?.getItem(player.selectedSlotIndex);
}
function consume(player, item, originalSlot) {
    if (player.selectedSlotIndex !== originalSlot)
        return false;
    const bag = player.getComponent(EntityComponentTypes.Inventory)?.container;
    const stack = bag?.getItem(originalSlot);
    if (!bag || !stack || stack.typeId !== item)
        return false;
    const amount = itemRemainder(stack.amount, player.getGameMode() === GameMode.Creative);
    if (amount !== stack.amount) {
        if (amount === 0)
            bag.setItem(originalSlot, undefined);
        else {
            stack.amount = amount;
            bag.setItem(originalSlot, stack);
        }
    }
    return true;
}
function riders(entity) {
    return entity.getComponent(EntityComponentTypes.Rideable)?.getRiders() ?? [];
}
function rememberMount(player, entity, kind, state) {
    const record = { entity: entity.id, kind, flying: state.flying,
        wet: bodyInWater(entity), dimension: entity.dimension.id };
    const text = JSON.stringify(record);
    if (player.getDynamicProperty(MOUNT_KEY) !== text)
        player.setDynamicProperty(MOUNT_KEY, text);
}
function effect(player, id, ticks) {
    // Do not replace a longer effect supplied by another pack or a potion.
    if ((player.getEffect(id)?.duration ?? 0) < ticks - 10)
        player.addEffect(id, ticks, { showParticles: false });
}
function waterAt(entity, at) {
    try {
        const block = entity.dimension.getBlock(at);
        return block?.typeId === 'minecraft:water' || block?.typeId === 'minecraft:flowing_water';
    }
    catch {
        return false;
    } // Unloaded chunks count as a closed boundary.
}
function bodyInWater(entity) {
    return entity.isInWater || waterAt(entity, { ...entity.location, y: entity.location.y + 0.5 });
}
function clearCell(player, pos) {
    try {
        // Test the player's entire narrow body, including block-boundary corners.
        for (const x of [-0.31, 0.31])
            for (const z of [-0.31, 0.31])
                for (const y of [0, 0.9, 1.8]) {
                    const block = player.dimension.getBlock({ x: pos.x + x, y: pos.y + y, z: pos.z + z });
                    if (!block || (!block.isAir && !waterAt(player, { x: pos.x + x, y: pos.y + y, z: pos.z + z })))
                        return false;
                }
        return true;
    }
    catch {
        return false;
    }
}
function protectDismount(player, record) {
    if (record.kind === 'evie' && record.flying)
        effect(player, 'slow_falling', 6000);
    if (record.kind === 'eli' && record.wet)
        effect(player, 'water_breathing', 1200);
    if (player.dimension.id !== record.dimension || clearCell(player, player.location))
        return;
    const origin = player.location;
    for (const radius of [2, 3, 4, 5])
        for (const y of [0, 1, 2])
            for (let n = 0; n < 8; n++) {
                const at = { x: origin.x + Math.cos(n * Math.PI / 4) * radius,
                    y: origin.y + y, z: origin.z + Math.sin(n * Math.PI / 4) * radius };
                if (clearCell(player, at) && player.tryTeleport(at, { checkForBlocks: true }))
                    return;
            }
    tell(player, 'Dismount space is blocked — move to open space.');
}
function settle(entity, state) {
    if (kindOf(entity) === 'evie' && state.flying) {
        entity.triggerEvent('ltw_mobs:ground');
        state.flying = false;
        save(entity, state);
        entity.clearVelocity();
    }
    entity.triggerEvent(state.stay ? 'ltw_mobs:stay' : 'ltw_mobs:follow');
}
function handleInteraction(player, entity, item, slot, crouching) {
    if (!player.isValid || !entity.isValid || player.dimension.id !== entity.dimension.id)
        return;
    const delta = { x: player.location.x - entity.location.x, y: player.location.y - entity.location.y, z: player.location.z - entity.location.z };
    if (Math.hypot(delta.x, delta.y, delta.z) > 10)
        return;
    const kind = kindOf(entity);
    if (!kind)
        return;
    // Revalidate the hand after leaving the read-only before-event callback.
    if (player.selectedSlotIndex !== slot || held(player)?.typeId !== item)
        return;
    tracked.set(entity.id, entity);
    const state = stateOf(entity);
    const action = interaction(state, kind, player.id, item, crouching, riders(entity).length > 0);
    switch (action) {
        case 'feed': {
            const next = feed(state, player.id);
            if (next.owner) {
                const tameable = entity.getComponent(EntityComponentTypes.Tameable);
                if (!tameable?.tame(player)) {
                    tell(player, 'Taming failed. Keep your food and try again.');
                    return;
                }
            }
            if (!consume(player, FOOD[kind], slot))
                return;
            save(entity, next);
            if (next.owner)
                entity.triggerEvent('ltw_mobs:tame');
            showHearts(entity);
            tell(player, next.owner ? `${kind === 'evie' ? 'Evie' : 'Eli'} is your companion! Add a saddle to ride.` : `Trust: ${next.trust}/5`);
            break;
        }
        case 'saddle':
            if (!consume(player, 'minecraft:saddle', slot))
                return;
            state.saddled = true;
            save(entity, state);
            entity.triggerEvent('ltw_mobs:saddle');
            tell(player, 'Saddle equipped. Empty your hand, then interact to ride.');
            break;
        case 'toggle':
            state.stay = !state.stay;
            save(entity, state);
            settle(entity, state);
            tell(player, state.stay ? 'Staying here.' : kind === 'eli' ? 'Following you in water.' : 'Following you.');
            break;
        case 'mount': {
            state.stay = false;
            entity.triggerEvent('ltw_mobs:mount');
            // Property/component group events apply on the next simulation update.
            save(entity, state);
            const rideable = entity.getComponent(EntityComponentTypes.Rideable);
            if (!rideable?.addRider(player)) {
                settle(entity, state);
                tell(player, 'Could not mount. Try again in open space.');
                return;
            }
            lastRiders.set(entity.id, player.id);
            rememberMount(player, entity, kind, state);
            tell(player, kind === 'evie' ? 'Jump to take off. Look where you want to fly.' : 'Move forward and look where you want to swim.');
            break;
        }
        case 'not_owner':
            tell(player, 'This companion belongs to another player.');
            break;
        case 'need_food':
            tell(player, kind === 'evie' ? 'Feed Evie 5 glow berries to tame her.' : 'Feed Eli 5 tropical fish to tame him.');
            break;
        case 'need_saddle':
            tell(player, 'Equip a saddle before riding.');
            break;
        case 'occupied':
            tell(player, 'This companion already has a rider.');
            break;
        case 'none':
            tell(player, 'Use an empty hand to ride. Crouch + interact to follow/stay.');
            break;
    }
}
world.beforeEvents.playerInteractWithEntity.subscribe(event => {
    if (!kindOf(event.target))
        return;
    event.cancel = true; // Script validates ownership before native mounting can occur.
    const { player, target } = event;
    const item = event.itemStack?.typeId;
    const slot = player.selectedSlotIndex;
    const crouching = player.isSneaking;
    const key = player.id + ':' + target.id;
    if ((cooldowns.get(key) ?? -100) + 4 > system.currentTick)
        return;
    cooldowns.set(key, system.currentTick);
    system.run(() => {
        try {
            handleInteraction(player, target, item, slot, crouching);
        }
        catch (error) {
            report('interaction', error);
            if (player.isValid)
                tell(player, 'Companion error — check the Content Log.');
        }
    });
});
function takeoff(entity, player) {
    const state = stateOf(entity);
    if (state.flying || !canRide(state, player.id))
        return;
    state.flying = true;
    save(entity, state);
    takeoffs.set(entity.id, system.currentTick);
    entity.triggerEvent('ltw_mobs:flight');
    entity.applyImpulse({ x: 0, y: 0.35, z: 0 });
}
world.afterEvents.playerButtonInput.subscribe(event => {
    if (event.button !== InputButton.Jump || event.newButtonState !== ButtonState.Pressed)
        return;
    try {
        const mount = event.player.getComponent(EntityComponentTypes.Riding)?.entityRidingOn;
        if (mount && kindOf(mount) === 'evie')
            takeoff(mount, event.player);
    }
    catch (error) {
        report('takeoff input', error);
    }
});
/** Keep the collision-sized submerged body in water, allowing open air above it.
 * Check intermediate positions too, so a boost cannot skip a narrow shore.
 */
function waterVelocity(entity, velocity) {
    for (const distance of [0.5, 1, 2]) {
        const pos = { x: entity.location.x + velocity.x * distance,
            y: entity.location.y + velocity.y * distance, z: entity.location.z + velocity.z * distance };
        for (const x of [-1.4, 0, 1.4])
            for (const z of [-1.4, 0, 1.4]) {
                const foot = { x: pos.x + x, y: pos.y + 0.25, z: pos.z + z };
                if (!waterAt(entity, foot)) {
                    // At the water surface, suppress upward movement without losing steering.
                    if (velocity.y > 0)
                        return waterVelocity(entity, { ...velocity, y: 0 });
                    return { x: 0, y: 0, z: 0 };
                }
                // A low cave ceiling or solid upper body cell is also a closed boundary.
                const top = entity.dimension.getBlock({ ...foot, y: pos.y + 2.2 });
                if (!top || (!top.isAir && top.typeId !== 'minecraft:water' && top.typeId !== 'minecraft:flowing_water'))
                    return { x: 0, y: 0, z: 0 };
            }
    }
    return velocity;
}
function moveEli(entity, player, state, players) {
    const wet = bodyInWater(entity);
    if (swimModes.get(entity.id) !== wet) {
        entity.triggerEvent(wet ? 'ltw_mobs:flight' : 'ltw_mobs:ground');
        swimModes.set(entity.id, wet);
    }
    if (!wet) {
        if (entity.isOnGround)
            entity.clearVelocity();
        return;
    }
    let desired = { x: 0, y: 0, z: 0 };
    if (player) {
        const input = player.inputInfo.getMovementVector();
        desired = swimVector(player.getViewDirection(), input.x, input.y);
    }
    else if (state.owner && !state.stay) {
        const owner = players.get(state.owner);
        if (owner && owner.dimension.id === entity.dimension.id && bodyInWater(owner)) {
            const delta = { x: owner.location.x - entity.location.x, y: owner.location.y - entity.location.y, z: owner.location.z - entity.location.z };
            const distance = Math.hypot(delta.x, delta.y, delta.z);
            if (distance > 5)
                desired = { x: delta.x / distance * 0.3, y: delta.y / distance * 0.3, z: delta.z / distance * 0.3 };
        }
    }
    const safe = waterVelocity(entity, desired);
    entity.clearVelocity();
    entity.applyImpulse(safe);
    if (Math.hypot(safe.x, safe.z) > 0.001)
        entity.setRotation({ x: 0, y: Math.atan2(-safe.x, safe.z) * 180 / Math.PI });
}
function repairLoadedState(entity, state) {
    if (state.owner && !entity.getProperty('ltw_mobs:tamed'))
        entity.triggerEvent('ltw_mobs:tame');
    if (state.saddled && !entity.getProperty('ltw_mobs:saddled'))
        entity.triggerEvent('ltw_mobs:saddle');
    // A script/world reload can interrupt a ride. Resume a safe, unoccupied mode.
    if (!riders(entity).length)
        settle(entity, state);
}
function track(entity) {
    if (!kindOf(entity) || !entity.isValid)
        return;
    tracked.set(entity.id, entity);
    try {
        repairLoadedState(entity, stateOf(entity));
    }
    catch (error) {
        report('load state', error);
    }
}
world.afterEvents.entitySpawn.subscribe(event => track(event.entity));
world.afterEvents.entityLoad.subscribe(event => track(event.entity));
system.runInterval(() => {
    const players = new Map(world.getAllPlayers().map(player => [player.id, player]));
    for (const [id, entity] of tracked) {
        if (!entity.isValid) {
            tracked.delete(id);
            takeoffs.delete(id);
            swimModes.delete(id);
            lastRiders.delete(id);
            continue;
        }
        try {
            const kind = kindOf(entity);
            const state = stateOf(entity);
            const occupants = riders(entity);
            const first = occupants[0];
            const player = first instanceof Player ? first : undefined;
            if (!player && lastRiders.delete(id)) {
                entity.clearVelocity();
                settle(entity, state);
            }
            if (first && (!player || !canRide(state, player.id))) {
                if (player)
                    protectDismount(player, { entity: id, kind, flying: state.flying, wet: entity.isInWater, dimension: entity.dimension.id });
                entity.getComponent(EntityComponentTypes.Rideable)?.ejectRiders();
                continue;
            }
            if (player) {
                lastRiders.set(id, player.id);
                if (kind === 'evie') {
                    if (!state.flying && player.inputInfo.getButtonState(InputButton.Jump) === ButtonState.Pressed)
                        takeoff(entity, player);
                    // takeoff() writes a fresh object; avoid overwriting it with this tick's snapshot.
                    const flying = stateOf(entity).flying;
                    state.flying = flying;
                    const input = player.inputInfo.getMovementVector();
                    if (flying && entity.isOnGround && (takeoffs.get(id) ?? -100) + 20 < system.currentTick && player.getViewDirection().y < -0.15) {
                        state.flying = false;
                        save(entity, state);
                        entity.triggerEvent('ltw_mobs:ground');
                    }
                    else if (flying && Math.hypot(input.x, input.y) < 0.01)
                        entity.clearVelocity();
                    // Dismount protection is already active before the next damage tick.
                    if (state.flying)
                        effect(player, 'slow_falling', 40);
                }
                else {
                    if (bodyInWater(entity)) {
                        effect(player, 'water_breathing', 1200);
                        effect(player, 'night_vision', 220);
                    }
                }
                rememberMount(player, entity, kind, state);
            }
            else if (kind === 'evie') {
                // Includes owner disconnect: eliminate rider momentum and return to gravity.
                if (state.flying)
                    settle(entity, state);
                if (state.stay && entity.isOnGround)
                    entity.clearVelocity();
            }
            if (kind === 'eli')
                moveEli(entity, player, state, players);
        }
        catch (error) {
            report('companion tick', error);
        }
    }
    // Per-player persisted records also protect a dismount after a script reload.
    for (const player of players.values()) {
        try {
            const mount = player.getComponent(EntityComponentTypes.Riding)?.entityRidingOn;
            const kind = mount && kindOf(mount);
            if (mount && kind)
                continue;
            const text = player.getDynamicProperty(MOUNT_KEY);
            if (typeof text === 'string') {
                const record = JSON.parse(text);
                protectDismount(player, record);
                player.setDynamicProperty(MOUNT_KEY, undefined);
                const oldMount = tracked.get(record.entity);
                if (oldMount?.isValid && !riders(oldMount).length)
                    settle(oldMount, stateOf(oldMount));
            }
        }
        catch (error) {
            report('dismount', error);
        }
    }
    if (system.currentTick % 200 === 0) {
        for (const map of [cooldowns, messages, lastErrors])
            for (const [key, tick] of map)
                if (tick + 400 < system.currentTick)
                    map.delete(key);
    }
}, 1);
system.runInterval(() => {
    // Discover already-loaded creatures after a world open or script reload.
    for (const dimension of ['overworld', 'nether', 'the_end']) {
        try {
            for (const entity of world.getDimension(dimension).getEntities({ families: ['ltw_companion'] }))
                if (!tracked.has(entity.id))
                    track(entity);
        }
        catch (error) {
            report('creature discovery', error);
        }
    }
}, 20);
system.run(() => console.warn(`[LTW Mobs ${VERSION}] Ready. Spawn Evie and Eli using their Creative eggs.`));
