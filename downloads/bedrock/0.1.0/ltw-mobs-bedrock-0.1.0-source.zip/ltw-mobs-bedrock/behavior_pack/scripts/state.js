export const FOOD = {
    evie: 'minecraft:glow_berries', eli: 'minecraft:tropical_fish'
};
export function initialState() {
    return { version: 1, trust: 0, trustingPlayer: '', owner: '', saddled: false, stay: true, flying: false };
}
export function decodeState(value) {
    if (value === undefined)
        return initialState();
    if (typeof value !== 'string')
        throw new Error('Invalid companion save data');
    const s = JSON.parse(value);
    if (s.version !== 1 || !Number.isInteger(s.trust) || s.trust < 0 || s.trust > 5 ||
        typeof s.trustingPlayer !== 'string' || typeof s.owner !== 'string' ||
        ['saddled', 'stay', 'flying'].some(k => typeof s[k] !== 'boolean')) {
        throw new Error('Unsupported or invalid companion save data');
    }
    return s;
}
export function feed(s, player) {
    if (s.owner)
        return s;
    const trust = s.trustingPlayer === player ? Math.min(5, s.trust + 1) : 1;
    return { ...s, trustingPlayer: player, trust, owner: trust === 5 ? player : '', stay: true };
}
export function interaction(s, kind, player, item, crouching, occupied) {
    if (!s.owner)
        return item === FOOD[kind] ? 'feed' : 'need_food';
    if (s.owner !== player)
        return 'not_owner';
    if (item === 'minecraft:saddle' && !s.saddled)
        return 'saddle';
    if (occupied)
        return 'occupied';
    if (item !== undefined)
        return 'none';
    if (crouching)
        return 'toggle';
    return s.saddled ? 'mount' : 'need_saddle';
}
export function itemRemainder(amount, creative) {
    if (!Number.isInteger(amount) || amount < 1)
        throw new Error('Empty food or saddle stack');
    return creative ? amount : amount - 1;
}
export function canRide(s, player) {
    return s.owner === player && s.owner !== '' && s.saddled;
}
export function swimVector(view, lateral, forward, speed = 0.48) {
    const pitch = Math.max(-0.8, Math.min(0.8, view.y));
    const horizontal = Math.hypot(view.x, view.z);
    // Looking straight up/down keeps forward movement useful instead of dividing by zero.
    const vx = horizontal > 0.0001 ? view.x / horizontal : 0;
    const vz = horizontal > 0.0001 ? view.z / horizontal : 1;
    const h = Math.sqrt(1 - pitch * pitch);
    const desired = { x: vx * h * forward + vz * lateral * 0.65,
        y: pitch * forward, z: vz * h * forward - vx * lateral * 0.65 };
    const length = Math.max(1, Math.hypot(desired.x, desired.y, desired.z));
    return { x: desired.x * speed / length, y: desired.y * speed / length, z: desired.z * speed / length };
}
